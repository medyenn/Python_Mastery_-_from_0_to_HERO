import sys
import os
from typing import List, Dict, Tuple, Optional
from mazegen import MazeGenerator
from mazegen import COLORS
from mazegen import BOLD
from mazegen import RESET


def main() -> None:
    """The main program function, it handles parsing of the config file
    and assign the values, and displays the interactive menu to the user.

    Returns: None
    """

    # CONFIG VARIABLES
    WIDTH: int = 0
    HEIGHT: int = 0
    ENTRY: Tuple[int, int] = (-1, -1)
    EXIT: Tuple[int, int] = (-1, -1)
    OUTPUT_FILE: str = ""
    PERFECT: Optional[bool] = None
    SEED: Optional[int] = None

    config_file_name: Optional[str] = None

    if (len(sys.argv) >= 2):
        config_file_name = sys.argv[1]
    else:
        print(f"Usage: python3 {sys.argv[0]} <config_file>", file=sys.stderr)
        sys.exit(1)

    if config_file_name == "requirements.txt":
        print('You can\'t use "requirements.txt" as the '
              'config file!', file=sys.stderr)
        sys.exit(1)
    elif not config_file_name.endswith(".txt"):
        print("Please use a file with .txt "
              "extension as the config file!", file=sys.stderr)
        sys.exit(1)

    try:
        with open(config_file_name, 'r') as file:
            file_lines: List[str] = file.readlines()
    except Exception as e:
        print(f"Config File Error: {e}", file=sys.stderr)
        sys.exit(1)

    valid_keys: List[str] = [
        "width",
        "height",
        "entry",
        "exit",
        "output_file",
        "perfect",
        "seed"
    ]

    mandatory_keys: Dict[str, bool] = {
        "width": False,
        "height": False,
        "entry": False,
        "exit": False,
        "output_file": False,
        "perfect": False,
    }

    for line in file_lines:

        if (line.startswith("#") or len(line.strip()) == 0):
            continue

        key_value: List[str] = line.strip().split("=")
        key: str = key_value[0].strip().lower()
        value: str = ""
        if len(key_value) >= 2:
            value = key_value[1].strip()

        if (len(key_value) != 2 and key in valid_keys):
            print(f"Config error: please provide a correct value for:"
                  f" '{key_value[0].strip()}'", file=sys.stderr)
            sys.exit(1)
        elif (key not in valid_keys):
            print(f"Config error: '{key_value[0].strip()}' "
                  f"is not a valid config!", file=sys.stderr)
            sys.exit(1)

        if key == "width":
            try:
                WIDTH = int(value)
                mandatory_keys[key] = True
                if WIDTH <= 0:
                    raise ValueError("WIDTH can't be 0 or negative!")
                # if WIDTH > 100:
                #     raise ValueError("WIDTH is too long (>100)!")
            except ValueError as e:
                print(f"Width config error: {e}", file=sys.stderr)
                sys.exit(1)

        if key == "height":
            try:
                HEIGHT = int(value)
                mandatory_keys[key] = True
                if HEIGHT <= 0:
                    raise ValueError("HEIGHT cant's be 0 or negative!")
                # if HEIGHT > 50:
                #     raise ValueError("HEIGHT is too long! (> 50)")
            except ValueError as e:
                print(f"Height config error: {e}", file=sys.stderr)
                sys.exit(1)

        if key == "entry":
            try:
                entry_str: List[str] = value.split(",")
                if (len(entry_str) == 2):
                    ENTRY = (int(entry_str[0]), int(entry_str[1]))
                    mandatory_keys[key] = True
                    if EXIT != (-1, -1):
                        if ENTRY == EXIT:
                            raise ValueError("Entry and Exit can't be "
                                             "the same!")
                else:
                    raise ValueError("Invalid Entry Cell (use: x,y)")

            except ValueError as e:
                print(f"Entry config Error: {e}", file=sys.stderr)
                sys.exit(1)

        if key == "exit":

            try:
                exit_str: List[str] = value.split(",")
                if (len(exit_str) == 2):
                    EXIT = (int(exit_str[0]), int(exit_str[1]))
                    mandatory_keys[key] = True
                    if ENTRY != (-1, -1):
                        if EXIT == ENTRY:
                            raise ValueError("Entry and Exit can't be "
                                             "the same!")
                else:
                    raise ValueError("Invalid Exit Cell (use: x,y)")

            except ValueError as e:
                print(f"Exit config error: {e}", file=sys.stderr)
                sys.exit(1)

        if key == "output_file":
            if value == "requirements.txt":
                print('You can\'t use "requirements.txt" as the '
                      'output file!', file=sys.stderr)
                sys.exit(1)
            elif value == config_file_name:
                print("You can't use the config file name as the "
                      "output file!", file=sys.stderr)
                sys.exit(1)
            elif not value.endswith(".txt"):
                print("Please use a file with .txt "
                      "extension as the output file!", file=sys.stderr)
                sys.exit(1)
            OUTPUT_FILE = value
            mandatory_keys[key] = True

        if key == "perfect":

            if value.lower() == "true":
                PERFECT = True
            elif value.lower() == "false":
                PERFECT = False
            else:
                print("Invalid config for PERFECT "
                      "(use: True or False)", file=sys.stderr)
                sys.exit(1)
            mandatory_keys[key] = True

        if key == "seed":

            try:
                SEED = int(value)
            except ValueError as e:
                print(f"Seed config error: {e}", file=sys.stderr)
                sys.exit(1)

    missing_mandatory: bool = False
    for key, val in mandatory_keys.items():
        if val is False:
            missing_mandatory = True
            print(f"Mandatory config variable missing:"
                  f" {key.upper()}", file=sys.stderr)

    if missing_mandatory:
        sys.exit(1)

    if (
        ENTRY[0] < 0 or
        ENTRY[0] > WIDTH - 1 or
        ENTRY[1] < 0 or
        ENTRY[1] > HEIGHT - 1
    ):
        print("Invalid Entry cell coordinates", file=sys.stderr)
        sys.exit(1)

    if (
        EXIT[0] < 0 or
        EXIT[0] > WIDTH - 1 or
        EXIT[1] < 0 or
        EXIT[1] > HEIGHT - 1
    ):
        print("Invalid Exit cell coordinates", file=sys.stderr)
        sys.exit(1)

    is_enough_cells: bool = False
    if WIDTH < 9 or HEIGHT < 7:
        is_enough_cells = True

    maze: MazeGenerator = MazeGenerator(
        WIDTH, HEIGHT, ENTRY, EXIT, OUTPUT_FILE, PERFECT, SEED
    )

    if not is_enough_cells:
        maze.render_pattern()
    maze.dfs_algo()
    if maze.PERFECT is False:
        maze.make_maze_imperfect()
    maze.find_solution()
    maze.generate_output()
    default_algo: str = "dfs"
    invalid_choice: bool = False
    animation_speed: str = "[Fast]"

    while True:
        maze.render_maze()

        if is_enough_cells:
            print(f'{COLORS["Red"]["value"]}Error: '
                  f'not enough cells for 42 pattern\n{RESET}')

        # Interactive Menu
        print('============= A-Maze-ing =============\n')

        print(f'1. Regenerate a new maze using '
              f'{BOLD}[{"DFS" if default_algo == "dfs" else "Prims"}]{RESET}')

        print("2. Change default algorithm")

        print(f'3. {"Hide" if maze.show_path else "Show"} solution path')

        print(f'4. {"Disable" if maze.render_animation else "Enable"} '
              f'rendering animation')

        print("5. Change animation speed ", end="")
        if maze.render_animation:
            print(f"{BOLD}{animation_speed}{RESET}")
        else:
            print("")

        print(f'6. Change wall colors '
              f'{maze.wall_color["value"]}{BOLD}[{maze.wall_color["name"]}]'
              f'{RESET}')

        print(f'7. Change solution path color '
              f'{maze.solution_color["value"]}'
              f'{BOLD}[{maze.solution_color["name"]}]{RESET}')

        print(f'8. Change 42 pattern color '
              f'{maze.pattern_color["value"]}{BOLD}'
              f'[{maze.pattern_color["name"]}]{RESET}')

        print(f'9. Toggle PERFECT {BOLD}[{"True" if maze.PERFECT else "False"}'
              f']{RESET}')

        print("0. Quit\n")

        if invalid_choice is True:
            print(f'{COLORS["Red"]["value"]}[!] '
                  f'Please select a valid choice!{RESET}')
            invalid_choice = False

        try:
            choice: str = input("Choice? (0-9): ").strip()
        except (KeyboardInterrupt, EOFError):
            os.system("clear")
            sys.exit(0)

        # Regenerate new maze
        if choice == "1":
            maze.show_path = False
            maze.reset_grid()
            if not is_enough_cells:
                maze.render_pattern()
            if default_algo == "dfs":
                maze.dfs_algo()
            else:
                maze.prims_algo()
            if maze.PERFECT is False:
                maze.make_maze_imperfect()
            maze.generate_output()
            maze.find_solution()

        # Change default algorithm
        elif choice == "2":
            while True:
                maze.render_maze()

                print("==== Change Default Algorithm ====\n")
                print("1. DFS Algorithm")
                print("2. Prim's Algorithm")
                print("0. Go back\n")

                if invalid_choice is True:
                    print(f'{COLORS["Red"]["value"]}[!] '
                          f'Please select a valid choice!{RESET}')
                    invalid_choice = False

                try:
                    algo_choice: str = input("Choice? (0-2): ").strip()
                    if algo_choice == "1":
                        default_algo = "dfs"
                        break
                    elif algo_choice == "2":
                        default_algo = "prims"
                        break
                    elif algo_choice == "0":
                        break
                    else:
                        invalid_choice = True
                except (KeyboardInterrupt, EOFError):
                    os.system("clear")
                    sys.exit(0)

        # Show/Hide solution path
        elif choice == "3":
            if maze.show_path:
                maze.show_path = False
            else:
                maze.show_path = True

        # Activate/Disable rendering animation
        elif choice == "4":
            if maze.render_animation:
                maze.render_animation = False
            else:
                maze.render_animation = True

        # Change animation speed
        elif choice == "5":
            while True:
                maze.render_maze()

                # Choose animation speed menu
                print("==== Change Animation Speed ====\n")
                print("1. Fast")
                print("2. Slow")
                print("0. Go back\n")

                if invalid_choice is True:
                    print(f'{COLORS["Red"]["value"]}[!] '
                          f'Please select a valid choice!{RESET}')
                    invalid_choice = False

                try:
                    speed_choice: str = input("Choice? (0-3): ").strip()
                    if speed_choice == "1":
                        maze.animation_speed = 0.005
                        animation_speed = "[Fast]"
                        break
                    elif speed_choice == "2":
                        maze.animation_speed = 0.08
                        animation_speed = "[Slow]"
                        break
                    elif speed_choice == "0":
                        break
                    else:
                        invalid_choice = True
                except (KeyboardInterrupt, EOFError):
                    os.system("clear")
                    sys.exit(0)

        # Change walls color
        elif choice == "6":
            while True:
                maze.render_maze()

                print("==== Change Wall Color ====\n")
                print(f'1. {COLORS["Green"]["value"]}Green{RESET}')
                print(f'2. {COLORS["Orange"]["value"]}Orange{RESET}')
                print(f'3. {COLORS["Purple"]["value"]}Purple{RESET}')
                print(f'4. {COLORS["Pink"]["value"]}Pink{RESET}')
                print(f'5. {COLORS["Sky Blue"]["value"]}Sky Blue{RESET}')
                print(f'6. {COLORS["Coral"]["value"]}Coral{RESET}')
                print(f'7. {COLORS["Yellow"]["value"]}Yellow{RESET}')
                print(f'8. {COLORS["Teal"]["value"]}Teal{RESET}')
                print(f'9. {COLORS["Lavender"]["value"]}Lavender{RESET}')
                print(f'10. {COLORS["Crimson"]["value"]}Crimson{RESET}')
                print("0. Go back\n")

                if invalid_choice is True:
                    print(f'{COLORS["Red"]["value"]}[!] '
                          f'Please select a valid choice!{RESET}')
                    invalid_choice = False

                try:
                    wall_color_choice: str = input("Choice? (0-10): ").strip()
                    if wall_color_choice == "1":
                        maze.wall_color = COLORS["Green"]
                    elif wall_color_choice == "2":
                        maze.wall_color = COLORS["Orange"]
                    elif wall_color_choice == "3":
                        maze.wall_color = COLORS["Purple"]
                    elif wall_color_choice == "4":
                        maze.wall_color = COLORS["Pink"]
                    elif wall_color_choice == "5":
                        maze.wall_color = COLORS["Sky Blue"]
                    elif wall_color_choice == "6":
                        maze.wall_color = COLORS["Coral"]
                    elif wall_color_choice == "7":
                        maze.wall_color = COLORS["Yellow"]
                    elif wall_color_choice == "8":
                        maze.wall_color = COLORS["Teal"]
                    elif wall_color_choice == "9":
                        maze.wall_color = COLORS["Lavender"]
                    elif wall_color_choice == "10":
                        maze.wall_color = COLORS["Crimson"]
                    elif wall_color_choice == "0":
                        break
                    else:
                        invalid_choice = True
                except (KeyboardInterrupt, EOFError):
                    os.system("clear")
                    sys.exit(0)

        # Change solution path color
        elif choice == "7":
            while True:
                maze.render_maze()

                print("==== Change Solution Path Color ====\n")
                print(f'1. {COLORS["Green"]["value"]}Green{RESET}')
                print(f'2. {COLORS["Orange"]["value"]}Orange{RESET}')
                print(f'3. {COLORS["Purple"]["value"]}Purple{RESET}')
                print(f'4. {COLORS["Pink"]["value"]}Pink{RESET}')
                print(f'5. {COLORS["Sky Blue"]["value"]}Sky Blue{RESET}')
                print(f'6. {COLORS["Coral"]["value"]}Coral{RESET}')
                print(f'7. {COLORS["Yellow"]["value"]}Yellow{RESET}')
                print(f'8. {COLORS["Teal"]["value"]}Teal{RESET}')
                print(f'9. {COLORS["Lavender"]["value"]}Lavender{RESET}')
                print(f'10. {COLORS["Crimson"]["value"]}Crimson{RESET}')
                print("0. Go back\n")

                if invalid_choice is True:
                    print(f'{COLORS["Red"]["value"]}[!] '
                          f'Please select a valid choice!{RESET}')
                    invalid_choice = False

                try:
                    path_color_choice: str = input("Choice? (0-10): ").strip()
                    if path_color_choice == "1":
                        maze.solution_color = COLORS["Green"]
                        if not maze.show_path:
                            break
                    elif path_color_choice == "2":
                        maze.solution_color = COLORS["Orange"]
                        if not maze.show_path:
                            break
                    elif path_color_choice == "3":
                        maze.solution_color = COLORS["Purple"]
                        if not maze.show_path:
                            break
                    elif path_color_choice == "4":
                        maze.solution_color = COLORS["Pink"]
                        if not maze.show_path:
                            break
                    elif path_color_choice == "5":
                        maze.solution_color = COLORS["Sky Blue"]
                        if not maze.show_path:
                            break
                    elif path_color_choice == "6":
                        maze.solution_color = COLORS["Coral"]
                        if not maze.show_path:
                            break
                    elif path_color_choice == "7":
                        maze.solution_color = COLORS["Yellow"]
                        if not maze.show_path:
                            break
                    elif path_color_choice == "8":
                        maze.solution_color = COLORS["Teal"]
                        if not maze.show_path:
                            break
                    elif path_color_choice == "9":
                        maze.solution_color = COLORS["Lavender"]
                        if not maze.show_path:
                            break
                    elif path_color_choice == "10":
                        maze.solution_color = COLORS["Crimson"]
                        if not maze.show_path:
                            break
                    elif path_color_choice == "0":
                        break
                    else:
                        invalid_choice = True
                except (KeyboardInterrupt, EOFError):
                    os.system("clear")
                    sys.exit(0)

        # Change 42 pattern color
        elif choice == "8":
            while True:
                maze.render_maze()

                print("==== Change 42 Pattern Color ====\n")
                print(f'1. {COLORS["Green"]["value"]}Green{RESET}')
                print(f'2. {COLORS["Orange"]["value"]}Orange{RESET}')
                print(f'3. {COLORS["Purple"]["value"]}Purple{RESET}')
                print(f'4. {COLORS["Pink"]["value"]}Pink{RESET}')
                print(f'5. {COLORS["Sky Blue"]["value"]}Sky Blue{RESET}')
                print(f'6. {COLORS["Coral"]["value"]}Coral{RESET}')
                print(f'7. {COLORS["Yellow"]["value"]}Yellow{RESET}')
                print(f'8. {COLORS["Teal"]["value"]}Teal{RESET}')
                print(f'9. {COLORS["Lavender"]["value"]}Lavender{RESET}')
                print(f'10. {COLORS["Crimson"]["value"]}Crimson{RESET}')
                print("0. Go back\n")

                if invalid_choice is True:
                    print(f'{COLORS["Red"]["value"]}[!] '
                          f'Please select a valid choice!{RESET}')
                    invalid_choice = False

                try:
                    pattern_choice: str = input("Choice? (0-10): ").strip()
                    if pattern_choice == "1":
                        maze.pattern_color = COLORS["Green"]
                    elif pattern_choice == "2":
                        maze.pattern_color = COLORS["Orange"]
                    elif pattern_choice == "3":
                        maze.pattern_color = COLORS["Purple"]
                    elif pattern_choice == "4":
                        maze.pattern_color = COLORS["Pink"]
                    elif pattern_choice == "5":
                        maze.pattern_color = COLORS["Sky Blue"]
                    elif pattern_choice == "6":
                        maze.pattern_color = COLORS["Coral"]
                    elif pattern_choice == "7":
                        maze.pattern_color = COLORS["Yellow"]
                    elif pattern_choice == "8":
                        maze.pattern_color = COLORS["Teal"]
                    elif pattern_choice == "9":
                        maze.pattern_color = COLORS["Lavender"]
                    elif pattern_choice == "10":
                        maze.pattern_color = COLORS["Crimson"]
                    elif pattern_choice == "0":
                        break
                    else:
                        invalid_choice = True
                except (KeyboardInterrupt, EOFError):
                    os.system("clear")
                    sys.exit(0)

        # Activate/Deactivate is perfect
        elif choice == "9":
            if maze.PERFECT:
                maze.PERFECT = False
            else:
                maze.PERFECT = True

        # Quit program
        elif choice == "0":
            os.system("clear")
            sys.exit(0)

        # Any other invalid choice
        else:
            invalid_choice = True


if __name__ == "__main__":
    main()
