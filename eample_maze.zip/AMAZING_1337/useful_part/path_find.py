from typing import List, Dict, Tuple, Optional
from collections import deque
from mazegen.Cell import Cell


class Path_finder:

    DIRECTIONS: list[tuple] = [
        (0, -1, 1, 4),
        (1, 0, 2, 8),
        (0, 1, 4, 1),
        (-1, 0, 8, 2)
    ]

    def __init__(
        self,
        WIDTH: int,
        HEIGHT: int,
        ENTRY: Tuple[int, int],
        EXIT: Tuple[int, int],
        OUTPUT_FILE: str,
        PERFECT: Optional[bool],
        SEED: Optional[int] = None
    ) -> None:
        """Initialize the MazeGenerator with configuration parameters.

        Args:
            WIDTH (int): The width of the maze in cells.
            HEIGHT (int): The height of the maze in cells.
            ENTRY (Tuple[int, int]): The entry point coordinates.
            EXIT (Tuple[int, int]): The exit point coordinates.
            OUTPUT_FILE (str): File where the maze will be saved.
            PERFECT (Optional[bool]): Whether to generate a perfect maze.
            SEED (Optional[int]): Random seed for reproducibility.

        Returns:
            None
        """

        self.WIDTH: int = WIDTH
        self.HEIGHT: int = HEIGHT
        self.ENTRY: Tuple[int, int] = ENTRY
        self.EXIT: Tuple[int, int] = EXIT
        self.OUTPUT_FILE: str = OUTPUT_FILE
        self.PERFECT: Optional[bool] = PERFECT
        self.SEED: Optional[int] = SEED
        self.grid: List[List[Cell]] = [
                [
                    Cell(15) for _ in range(self.WIDTH)
                ] for _ in range(self.HEIGHT)
            ]
        self.solution_path: List[tuple] = []
        self.show_path: bool = False
        self.render_animation: bool = False
        self.animation_speed: float = 0.005
        self.wall_color: Dict[str, str] = {
            "name": "Green",
            "value": "\033[38;2;86;130;3m"
        }
        self.solution_color: Dict[str, str] = {
            "name": "Yellow",
            "value": "\033[38;2;255;213;0m"
        }
        self.pattern_color: Dict[str, str] = {
            "name": "Green",
            "value": "\033[38;2;86;130;3m"
        }

    def find_solution(self) -> None:

        directions: List[tuple] = [
            (0, -1, 1),   # North
            (1,  0, 2),   # East
            (0,  1, 4),   # South
            (-1, 0, 8),   # West
        ]

        came_from: Dict = {self.ENTRY: None}
        queue: deque = deque([self.ENTRY])

        while queue:
            current_x, current_y = queue.popleft()

            if (current_x, current_y) == self.EXIT:
                break

            current_walls: int = self.grid[current_y][current_x].walls

            for dx, dy, wall_mask in directions:
                nx: int = current_x + dx
                ny: int = current_y + dy

                if (
                    (0 <= nx < self.WIDTH)
                    and (0 <= ny < self.HEIGHT)
                    and (current_walls & wall_mask) == 0
                    and (nx, ny) not in came_from
                ):
                    came_from[(nx, ny)] = (current_x, current_y)
                    queue.append((nx, ny))

        self.solution_path = []
        cell: Optional[Tuple[int, int]] = self.EXIT

        while cell is not None:
            self.solution_path.append(cell)
            cell = came_from.get(cell)

        self.solution_path.reverse()
