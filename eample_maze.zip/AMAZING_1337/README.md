*This project has been created as part of the 42 curriculum by [hryahi, sait-mou].*

## Description

**A-Maze-ing** is a Python-based maze generator that creates, solves, and visually renders mazes from a simple configuration file. The program generates mazes using one of two classic algorithms **Recursive Backtracker (DFS)** or **Prim's algorithm** and outputs the result both as a structured hexadecimal file and as an interactive visual display.

Key highlights:
- Generates **perfect mazes** (single unique path between entry and exit) or imperfect ones with open areas.
- Embeds a **"42" pattern** made of fully walled cells visible in the maze rendering.
- Supports **terminal ASCII rendering** with interactive controls (regenerate a new maze, change default maze, show/hide solution, enable rendering animation, change animation speed, change wall colors, change solution path color, change 42 pattern color and toggle perfect).
- Exports a reusable `MazeGenerator` Python package (`mazegen-*`) that can be installed via `pip`.
- Produces a structured output file with the maze grid, entry/exit coordinates, and the shortest solution path.

## Usage Examples

### Basic usage
```bash
python3 a_maze_ing.py config.txt
```

### Using a custom config
```bash
python3 a_maze_ing.py my_config.txt
```

### Interactive terminal controls (once the maze is displayed)
| Key | Action |
|-----|--------|
| `1` | Regenerate a new maze |
| `2` | Change default algorithm |
| `3` | Show solution path |
| `4` | Enable rendering animation |
| `5` | Change animation speed |
| `6` | Change wall colors |
| `7` | Change solution path color |
| `8` | Change 42 pattern color |
| `9` | Toggle PERFECT |
| `0` | Quit |

## Features

- **Two generation algorithms**: DFS (recursive backtracker) and Prim's algorithm.
- **Perfect and imperfect maze modes**: Controlled by the `PERFECT` flag.
- **Reproducible generation**: Provide a `SEED` value for deterministic output.
- **Hex output format**: Each cell encoded as one hexadecimal digit (4 wall bits: N, E, S, W).
- **Shortest path solving**: Finds and outputs the shortest path.
- **"42" Fixed Pattern**: A pattern of fully closed cells forming the number "42" embedded in the maze.
- **Interactive terminal display**: ASCII rendering with live controls for regeneration, path toggle, and color cycling.
- **Reusable module**: The core generator is packaged as `mazegen` for standalone use in other projects.
- **Bonus – Generation animation**: Watch the maze being built step by step in the terminal, costumize collors...



## Instructions

### Requirements
- Python 3.10 or later
- Dependencies listed in `requirements.txt`

### Installation
```bash
# Clone the repository
cd a-maze-ing
# Install dependencies
make install
```

### Running the Program
```bash
# Run with the default config file
make run
# Or run directly
python3 a_maze_ing.py config.txt
```

### Linting
```bash
# Run flake8 and mypy checks
make lint
```

### Debug Mode
```bash
make debug
```

### Cleanup
```bash
make clean
```



## Resources

### Maze generation & algorithms
- [Maze generation algorithms — Wikipedia](https://en.wikipedia.org/wiki/Maze_generation_algorithm)
- [Jamis Buck's blog — Maze algorithms (highly recommended)](https://weblog.jamisbuck.org/2011/2/7/maze-generation-algorithm-recap)
- [Graph theory & spanning trees — Khan Academy](https://www.khanacademy.org/computing/computer-science/algorithms)

### Python packaging
- [Python Packaging User Guide](https://packaging.python.org/en/latest/)
- [pyproject.toml reference](https://packaging.python.org/en/latest/specifications/pyproject-toml/)

### Tools & standards
- [flake8 documentation](https://flake8.pycqa.org/en/latest/)
- [mypy documentation](https://mypy.readthedocs.io/en/stable/)
- [PEP 257 – Docstring conventions](https://peps.python.org/pep-0257/)

## AI usage
**Claude** (Anthropic) was used during this project for:
- Drafting and structuring this README.
- Reviewing docstring formatting and PEP 257 compliance.
- Suggesting BFS path-finding logic (reviewed, tested, and rewritten by the team).
- Answering questions about `pyproject.toml` packaging syntax.

All AI-generated content was critically reviewed, tested, and understood by both team members before being included in the project. No code was submitted without full comprehension.



## Configuration File Format
The configuration file uses `KEY=VALUE` pairs (one per line). Lines beginning with `#` are treated as comments.

### Mandatory keys
| Key | Description | Example |
|-----|-------------|---------|
| `WIDTH` | Number of columns (cells) | `WIDTH=20` |
| `HEIGHT` | Number of rows (cells) | `HEIGHT=15` |
| `ENTRY` | Entry cell coordinates (x,y) | `ENTRY=0,0` |
| `EXIT` | Exit cell coordinates (x,y) | `EXIT=19,14` |
| `OUTPUT_FILE` | Path to the output file | `OUTPUT_FILE=maze.txt` |
| `PERFECT` | Generate a perfect maze? | `PERFECT=True` |

### Optional keys
| Key | Description | Default | Example |
|-----|-------------|---------|---------|
| `SEED` | Random seed for reproducibility | random | `SEED=42` |

### Example `config.txt`
```ini
# A-Maze-ing default configuration
WIDTH=20
HEIGHT=15
ENTRY=0,0
EXIT=19,14
OUTPUT_FILE=maze.txt
PERFECT=True
SEED=42
```



## Maze Generation Algorithms

### Algorithms chosen: DFS (Recursive Backtracker) & Prim's

**DFS / Recursive Backtracker** is the primary algorithm. It works by:
1. Starting at a random cell and marking it as visited.
2. Randomly choosing an unvisited neighbor, carving a passage to it, and recursing.
3. Backtracking when no unvisited neighbors remain, until the whole grid is explored.

**Prim's Algorithm** is offered as an alternative. It works by:
1. Starting with a single cell and adding its walls to a candidate list.
2. Randomly picking a wall from the list: if one side is unvisited, carve through and add its walls.
3. Repeating until all cells are visited.

### Why these algorithms?

**DFS** was chosen as the primary algorithm because it consistently produces **long, winding corridors** with fewer dead-ends — creating mazes that feel intricate and challenging to solve. It naturally produces perfect mazes, and its recursive structure makes it clean and straightforward to implement.

**Prim's** was added as a bonus to provide more branchy, tree-like mazes with many short dead-ends, a stylistically different feel from DFS. Supporting multiple algorithms also demonstrates how the architecture cleanly separates generation strategy from the rest of the program.

Both algorithms are implemented inside the reusable `MazeGenerator` class and selectable via the interative Panel.



## Output File Format
Each row of the maze is stored as one line of hexadecimal characters (one hex digit per cell). Each hex digit encodes which walls are **closed** using 4 bits:

| Bit | Direction |
|-----|-----------|
| 0 (LSB) | North |
| 1 | East |
| 2 | South |
| 3 | West |

A bit of `1` means the wall is **closed**, `0` means **open**.

**Example:** `A` = `1010` binary → East and West walls are closed.

After the grid, an empty line separates three additional lines:
1. Entry coordinates (`x,y`)
2. Exit coordinates (`x,y`)
3. The shortest path from entry to exit using `N`, `E`, `S`, `W` characters.


## Technical Choices

- **Language**: Python 3.10+ for modern type hints, `match` statements, and standard library quality.
- **Coding standard**: `flake8` for style, `mypy` with strict type checking for safety.
- **Path finding**: BFS (Breadth-First Search) guarantees the **shortest** path, not just any valid path.
- **"42" pattern**: Pre-computed as a set of cell coordinates that are forced to be fully walled (all 4 walls closed) before the main generation pass. These cells are excluded from the connectivity graph, which is why they are an explicit exception to the "no isolated cells" rule.
---

## Team & Project Management

### Team members

| Login | Role |
|-------|------|
| `hryahi` | Maze generation algorithms (DFS & Prim's), output file format, BFS solver, reusable `mazegen` package |
| `sait-mou` | Terminal visual renderer, interactive controls, "42" pattern integration, Makefile & project config |


### Tools used

- **Git** — version control and collaboration.
- **VS Code** — primary development environment.
- **mypy + flake8** — static analysis and linting.
- **Claude (AI)** — used for drafting the README structure, reviewing docstring style, and suggesting BFS implementation patterns. All generated suggestions were reviewed, tested, and adapted before inclusion. No code was blindly copy-pasted.



## MazeGenerator Documentation:
### Overview:

The MazeGenerator class creates procedurally generated mazes using either Depth-First Search (DFS) or Prim's algorithm. It supports perfect mazes, imperfect mazes, custom seeds for reproducibility, and pathfinding to generate solutions.

### Basic Instantiation and Usage:

### Simple Example:

```python

from mazegen.MazeGenerator import MazeGenerator

# Create a maze generator instance
maze = MazeGenerator(
    WIDTH=21,
    HEIGHT=21,
    ENTRY=(0, 0),
    EXIT=(20, 20),
    OUTPUT_FILE="maze_output.txt",
    PERFECT=True,
    SEED=None
)

# Render the 42 pattern inside the grid
maze.render_pattern()

# Generate maze using DFS algorithm
maze.dfs_algo()

# Generate maze using Prims algorithm
maze.prims_algo()

# make maze imperfect
maze.make_maze_imperfect()

# Display the maze
maze.render_maze()

# Finds the shortest path from entry to exit
maze.find_solution()

# Generates the output file content
maze.generate_output()

# Resets the grid to fully closed cells
maze.reset_grid()
```


### Constructor Parameters:

Parameter	 Type	             Description
WIDTH	     int	             The width of the maze in cells (e.g., 21).
HEIGHT	     int	             The height of the maze in cells (e.g., 21).
ENTRY	     Tuple[int, int]	 Starting position as (x, y) coordinates.
EXIT	     Tuple[int, int]	 Ending position as (x, y) coordinates.
OUTPUT_FILE  str	             File path where the maze will be saved (e.g., "maze.txt").
PERFECT	     Optional[bool]	     True for perfect maze (one solution), False for imperfect maze (multiple solutions).
SEED	     Optional[int]	     Random seed for reproducibility. Use None for random generation.


### Generation Methods:

- DFS Algorithm: Faster and uses less memory. Generates mazes with longer, winding corridors.

```python
maze = MazeGenerator(20, 20, (0, 0), (19, 19), "maze.txt", True, 42)
maze.render_pattern() # Optional
maze.dfs_algo()
```

- Prim's Algorithm: Slower but produces more balanced mazes with varied corridor lengths.

```python
maze = MazeGenerator(20, 20, (0, 0), (19, 19), "maze.txt", True, 42)
maze.render_pattern() # Optional
maze.prims_algo()
```

### Custom Parameters Example:

```python
# Create a larger maze with a specific seed for reproducibility
maze = MazeGenerator(
    WIDTH=51,
    HEIGHT=51,
    ENTRY=(5, 5),
    EXIT=(45, 45),
    OUTPUT_FILE="output.txt",
    PERFECT=False,  # Allow multiple solutions
    SEED=42      # Reproducible results
)
maze.render_pattern() # Optional
maze.dfs_algo()
```

### Accessing Generated Structure:

- Solution Path: After calling either dfs_algo() or prims_algo(), the solution is automatically computed and stored in self.solution_path:

```python
maze = MazeGenerator(20, 20, (0, 0), (19, 19), "maze.txt", True, None)
maze.render_pattern() # Optional
maze.dfs_algo()

# Access the solution path as a list of (x, y) coordinates
print("Solution path:", maze.solution_path)

# Get the length of the solution
print(f"Solution length: {len(maze.solution_path)} steps")
```

- Grid Structure: The maze is stored in self.grid as a 2D list of Cell objects. Each cell has a walls attribute (a 4-bit integer encoding which walls exist):

```python
# Access a specific cell
cell = maze.grid[10][10]
print(f"Cell walls value: {cell.walls}")  # Value 0-15 representing wall configuration

# Iterate through all cells
for y in range(maze.HEIGHT):
    for x in range(maze.WIDTH):
        cell = maze.grid[y][x]
        print(f"Cell ({x}, {y}): walls={cell.walls}")
```

- Output File: The maze is automatically saved to the specified OUTPUT_FILE in the following format:

[Hexadecimal wall values, one per cell, row by row]

[Entry coordinates: x,y]
[Exit coordinates: x,y]
[Solution directions: sequence of N/S/E/W characters]

- Display Options: Render with Animation

```python
maze = MazeGenerator(21, 21, (1, 1), (19, 19), "maze.txt", True, None)
maze.render_animation = True
maze.animation_speed = 0.01
maze.render_pattern() # Optional
maze.dfs_algo()  # Animation displays during generation
```

Display Solution Path:

```python
maze = MazeGenerator(21, 21, (1, 1), (19, 19), "maze.txt", True, None)
maze.render_pattern() # Optional
maze.dfs_algo()
maze.show_path = True  # Highlight solution in yellow
maze.render_maze()
```

- Complete Working Example:

```python
from mazegen.MazeGenerator import MazeGenerator

# Create and generate a maze
maze = MazeGenerator(
    WIDTH=31,
    HEIGHT=31,
    ENTRY=(0, 0),
    EXIT=(30, 30),
    OUTPUT_FILE="my_maze.txt",
    PERFECT=True,
    SEED=1337
)

# Generate using DFS
maze.render_pattern() # Optional
maze.dfs_algo()

# Display the maze with solution highlighted
maze.show_path = True
maze.render_maze()

# Access the solution
print(f"Entry: {maze.ENTRY}")
print(f"Exit: {maze.EXIT}")
print(f"Solution steps: {len(maze.solution_path)}")
print(f"Solution path: {maze.solution_path}")
```
