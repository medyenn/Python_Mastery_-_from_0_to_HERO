class Cell:
    """Represents a cell in a grid with wall configuration and state flags."""

    def __init__(self, walls: int):
        """Initializes a Cell instance.

        Args:
            walls (int): An integer representing the wall configuration
                of the cell.

        Attributes:
            walls (int): Wall configuration of the cell.
            visited (bool): Indicates whether the cell has been visited.
            fixed (bool): Indicates whether the cell is fixed (42 pattern).
        """
        self.walls = walls
        self.visited = False
        self.fixed = False
