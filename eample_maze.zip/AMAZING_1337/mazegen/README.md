
## MazeGenerator Documentation:
### Overview:

The MazeGenerator class creates procedurally generated mazes using either Depth-First Search (DFS) or Prim's algorithm. It supports perfect mazes, imperfect mazes, custom seeds for reproducibility, and pathfinding to generate solutions.

### Basic Instantiation and Usage:

### Simple Example:

```python

from mazegen.MazeGenerator import MazeGenerator

# Create a maze generator instance
maze = MazeGenerator(
    WIDTH=21,
    HEIGHT=21,
    ENTRY=(0, 0),
    EXIT=(20, 20),
    OUTPUT_FILE="maze_output.txt",
    PERFECT=True,
    SEED=None
)

# Render the 42 pattern inside the grid
maze.render_pattern()

# Generate maze using DFS algorithm
maze.dfs_algo()

# or Generate maze using Prims algorithm
maze.prims_algo()

# make maze imperfect
maze.make_maze_imperfect()

# Display the maze
maze.render_maze()


# Finds the shortest path from entry to exit
maze.find_solution()

maze.show_path = True
# Generates the output file content
maze.generate_output()

# Resets the grid to fully closed cells
maze.reset_grid()
```


### Constructor Parameters:

Parameter	 Type	             Description
WIDTH	     int	             The width of the maze in cells (e.g., 21).
HEIGHT	     int	             The height of the maze in cells (e.g., 21).
ENTRY	     Tuple[int, int]	 Starting position as (x, y) coordinates.
EXIT	     Tuple[int, int]	 Ending position as (x, y) coordinates.
OUTPUT_FILE  str	             File path where the maze will be saved (e.g., "maze.txt").
PERFECT	     Optional[bool]	     True for perfect maze (one solution), False for imperfect maze (multiple solutions).
SEED	     Optional[int]	     Random seed for reproducibility. Use None for random generation.


### Generation Methods:

- DFS Algorithm: Faster and uses less memory. Generates mazes with longer, winding corridors.

```python
maze = MazeGenerator(20, 20, (0, 0), (19, 19), "maze.txt", True, 42)
maze.render_pattern() # Optional
maze.dfs_algo()
```

- Prim's Algorithm: Slower but produces more balanced mazes with varied corridor lengths.

```python
maze = MazeGenerator(20, 20, (0, 0), (19, 19), "maze.txt", True, 42)
maze.render_pattern() # Optional
maze.prims_algo()
```

### Custom Parameters Example:

```python
# Create a larger maze with a specific seed for reproducibility
maze = MazeGenerator(
    WIDTH=51,
    HEIGHT=51,
    ENTRY=(5, 5),
    EXIT=(45, 45),
    OUTPUT_FILE="output.txt",
    PERFECT=False,  # Allow multiple solutions
    SEED=42      # Reproducible results
)
maze.render_pattern() # Optional
maze.dfs_algo()
```

### Accessing Generated Structure:

- Solution Path: After calling either dfs_algo() or prims_algo(), the solution is automatically computed and stored in self.solution_path:

```python
maze = MazeGenerator(20, 20, (0, 0), (19, 19), "maze.txt", True, None)
maze.render_pattern() # Optional
maze.dfs_algo()

# Access the solution path as a list of (x, y) coordinates
print("Solution path:", maze.solution_path)

# Get the length of the solution
print(f"Solution length: {len(maze.solution_path)} steps")
```

- Grid Structure: The maze is stored in self.grid as a 2D list of Cell objects. Each cell has a walls attribute (a 4-bit integer encoding which walls exist):

```python
# Access a specific cell
cell = maze.grid[10][10]
print(f"Cell walls value: {cell.walls}")  # Value 0-15 representing wall configuration

# Iterate through all cells
for y in range(maze.HEIGHT):
    for x in range(maze.WIDTH):
        cell = maze.grid[y][x]
        print(f"Cell ({x}, {y}): walls={cell.walls}")
```

- Output File: The maze is automatically saved to the specified OUTPUT_FILE in the following format:

[Hexadecimal wall values, one per cell, row by row]

[Entry coordinates: x,y]
[Exit coordinates: x,y]
[Solution directions: sequence of N/S/E/W characters]

- Display Options: Render with Animation

```python
maze = MazeGenerator(21, 21, (1, 1), (19, 19), "maze.txt", True, None)
maze.render_animation = True
maze.animation_speed = 0.01
maze.render_pattern() # Optional
maze.dfs_algo()  # Animation displays during generation
```

Display Solution Path:

```python
maze = MazeGenerator(21, 21, (1, 1), (19, 19), "maze.txt", True, None)
maze.render_pattern() # Optional
maze.dfs_algo()
maze.show_path = True  # Highlight solution in yellow
maze.render_maze()
```

- Complete Working Example:

```python
from mazegen.MazeGenerator import MazeGenerator

# Create and generate a maze
maze = MazeGenerator(
    WIDTH=31,
    HEIGHT=31,
    ENTRY=(0, 0),
    EXIT=(30, 30),
    OUTPUT_FILE="my_maze.txt",
    PERFECT=True,
    SEED=1337
)

# Generate using DFS
maze.render_pattern() # Optional
maze.dfs_algo()

# Display the maze with solution highlighted
maze.show_path = True
maze.render_maze()

# Access the solution
print(f"Entry: {maze.ENTRY}")
print(f"Exit: {maze.EXIT}")
print(f"Solution steps: {len(maze.solution_path)}")
print(f"Solution path: {maze.solution_path}")
```
