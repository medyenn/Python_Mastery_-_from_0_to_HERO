from typing import Dict


COLORS: Dict[str, Dict[str, str]] = {
    "Green": {
        "name": "Green",
        "value": "\033[38;2;86;130;3m"
    },
    "Orange": {
        "name": "Orange",
        "value": "\033[38;2;255;140;0m"
    },
    "Purple": {
        "name": "Purple",
        "value": "\033[38;2;148;0;211m"
    },
    "Pink": {
        "name": "Pink",
        "value": "\033[38;2;255;105;180m"
    },
    "Lime": {
        "name": "Lime",
        "value": "\033[38;2;50;205;50m"
    },
    "Sky Blue": {
        "name": "Sky Blue",
        "value": "\033[38;2;0;191;255m"
    },
    "Coral": {
        "name": "Coral",
        "value": "\033[38;2;255;99;71m"
    },
    "Yellow": {
        "name": "Yellow",
        "value": "\033[38;2;255;213;0m"
    },
    "Teal": {
        "name": "Teal",
        "value": "\033[38;2;0;180;180m"
    },
    "Lavender": {
        "name": "Lavender",
        "value": "\033[38;2;180;130;255m"
    },
    "Crimson": {
        "name": "Crimson",
        "value": "\033[38;2;220;20;60m"
    },
    "Red": {
        "name": "Red",
        "value": "\033[31m"
    }
}

BOLD: str = "\033[1m"
RESET: str = "\033[0m"
