import random
import os
import math
import time
import sys
from typing import List, Dict, Tuple, Optional
from collections import deque
from mazegen.Cell import Cell
from mazegen.Colors import COLORS
from mazegen.Colors import RESET


class MazeGenerator:
    """Generate and visualize mazes using various algorithms.

    This class creates maze structures with configurable dimensions, entry/exit
    points, and rendering options. It supports both perfect and imperfect mazes
    with optional animation and solution path display.

    Attributes:
        WIDTH (int): The width of the maze.
        HEIGHT (int): The height of the maze.
        ENTRY (Tuple[int, int]): The entry point coordinates.
        EXIT (Tuple[int, int]): The exit point coordinates.
        OUTPUT_FILE (str): Path to save the generated maze output.
        PERFECT (Optional[bool]): If True, generates a perfect maze with one
        solution.
        SEED (Optional[int]): Random seed for reproducible maze generation.
        grid (List[List[Cell]]): 2D grid of Cell objects representing the maze.
        solution_path (List[tuple]): List of coordinates of the solution path.
        show_path (bool): If True, displays the solution path in output.
        render_animation (bool): If True, animates the maze generation process.
        animation_speed (float): Speed of animation.
        wall_color (Dict[str, str]): Color configuration for walls.
        solution_color (Dict[str, str]): Color configuration for solution path.
        pattern_color (Dict[str, str]): Color configuration for 42 pattern.
    """

    DIRECTIONS: list[tuple] = [
        (0, -1, 1, 4),
        (1, 0, 2, 8),
        (0, 1, 4, 1),
        (-1, 0, 8, 2)
    ]

    def __init__(
        self,
        WIDTH: int,
        HEIGHT: int,
        ENTRY: Tuple[int, int],
        EXIT: Tuple[int, int],
        OUTPUT_FILE: str,
        PERFECT: Optional[bool],
        SEED: Optional[int] = None
    ) -> None:
        """Initialize the MazeGenerator with configuration parameters.

        Args:
            WIDTH (int): The width of the maze in cells.
            HEIGHT (int): The height of the maze in cells.
            ENTRY (Tuple[int, int]): The entry point coordinates.
            EXIT (Tuple[int, int]): The exit point coordinates.
            OUTPUT_FILE (str): File where the maze will be saved.
            PERFECT (Optional[bool]): Whether to generate a perfect maze.
            SEED (Optional[int]): Random seed for reproducibility.

        Returns:
            None
        """

        self.WIDTH: int = WIDTH
        self.HEIGHT: int = HEIGHT
        self.ENTRY: Tuple[int, int] = ENTRY
        self.EXIT: Tuple[int, int] = EXIT
        self.OUTPUT_FILE: str = OUTPUT_FILE
        self.PERFECT: Optional[bool] = PERFECT
        self.SEED: Optional[int] = SEED
        self.grid: List[List[Cell]] = [
                [
                    Cell(15) for _ in range(self.WIDTH)
                ] for _ in range(self.HEIGHT)
            ]
        self.solution_path: List[tuple] = []
        self.show_path: bool = False
        self.render_animation: bool = False
        self.animation_speed: float = 0.005
        self.wall_color: Dict[str, str] = {
            "name": "Green",
            "value": "\033[38;2;86;130;3m"
        }
        self.solution_color: Dict[str, str] = {
            "name": "Yellow",
            "value": "\033[38;2;255;213;0m"
        }
        self.pattern_color: Dict[str, str] = {
            "name": "Green",
            "value": "\033[38;2;86;130;3m"
        }

    def reset_grid(self) -> None:
        """Resets the full 2D grid to closed cells

        Returns: None
        """

        self.grid = [
                [
                    Cell(15) for _ in range(self.WIDTH)
                ] for _ in range(self.HEIGHT)
            ]

    def render_pattern(self) -> None:
        """Render a fixed "42" pattern in the maze grid.

        This method places a decorative "42" pattern (two digits) in the center
        of the maze by marking specific cells as fixed. The pattern
        requires a minimum maze size of 9x7 cells.
        Entry and exit points cannot overlap with the pattern cells.

        Returns:
            None

        Raises:
            SystemExit: If maze dimensions are less than 9x7 cells.
            SystemExit: If entry point overlaps with pattern cells.
            SystemExit: If exit point overlaps with pattern cells.
        """

        x_start: int = math.ceil(((self.WIDTH - 1) - 7) / 2)
        y_start: int = math.ceil(((self.HEIGHT - 1) - 5) / 2)

        four: List[tuple] = [
            (0, 0), (0, 2),
            (1, 0), (1, 2),
            (2, 0), (2, 1), (2, 2),
            (3, 2),
            (4, 2)
        ]

        two: List[tuple] = [
            (0, 4), (0, 5), (0, 6),
            (1, 6),
            (2, 4), (2, 5), (2, 6),
            (3, 4),
            (4, 4), (4, 5), (4, 6)
        ]

        for dy, dx in four + two:
            if (
                self.ENTRY[0] == x_start + dx and
                self.ENTRY[1] == y_start + dy
            ):
                print("Entry cell is part of 42 fixed pattern")
                sys.exit(1)
            if (
                self.EXIT[0] == x_start + dx and
                self.EXIT[1] == y_start + dy
            ):
                print("Exit cell is part of 42 fixed pattern")
                sys.exit(1)
            self.grid[y_start + dy][x_start + dx].fixed = True

    def get_bits(self, n: int) -> str:
        """Convert an integer to its 4-bit binary string representation.
        Args:
            n (int): The integer value to convert to binary (typically 0-15).

        Returns:
            str: A 4-character string of '0' and '1' representing binary form.
        """

        bits: str = ""
        for j in range(3, -1, -1):
            bits += str((n >> j) & 1)
        return bits

    def ft_is_in_path(self, x: int, y: int) -> bool:
        """Check if a cell coordinate is part of the maze solution path.

        Args:
            x (int): The x-coordinate (column) of the cell to check.
            y (int): The y-coordinate (row) of the cell to check.

        Returns:
            bool: True if the coordinate is in the solution path,
                  False otherwise.
        """

        if (x, y) in self.solution_path:
            return True
        return False

    def get_cell_top(self, n: int, x: int, y: int) -> str:
        """Generate the top border string representation of a maze cell.

        This method creates the visual top edge of a cell, determining whether
        to display a wall or an opening based on the cell's bit representation.
        If the solution path is enabled and the cell is part of it, the top
        border may be highlighted with the solution color.

        Args:
            n (int): A 4-bit integer encoding the cell's wall configuration.
                Bit 3 (rightmost) determines if the top wall exists (1) or
                opens (0).
            x (int): The x-coordinate (column) of the cell.
            y (int): The y-coordinate (row) of the cell.

        Returns:
            str: A colored string representing the top border of the cell.
                Returns either a solid wall or a wall with opening and content.
        """

        WALL: str = f'{self.wall_color["value"]}█{RESET}'
        WALL_CONTENT: str = "  "

        is_in_path: bool = self.ft_is_in_path(x, y)
        if self.show_path and is_in_path:
            if (x, y - 1) in self.solution_path:
                WALL_CONTENT = f'{self.solution_color["value"]}██{RESET}'

        if self.grid[y - 1][x].fixed:
            WALL = f'{self.pattern_color["value"]}█{RESET}'
            WALL_CONTENT = f'{self.pattern_color["value"]}██{RESET}'

        bits: str = self.get_bits(n)
        if (self.grid[y][x].fixed):
            WALL = f'{self.pattern_color["value"]}█{RESET}'
            WALL_CONTENT = f'{self.pattern_color["value"]}██{RESET}'
            return f'{WALL}{WALL_CONTENT}{WALL}'
        if (bits[3] == "1"):
            return f'{self.wall_color["value"]}████{RESET}'
        elif (bits[3] == "0"):
            return f'{WALL}{WALL_CONTENT}{WALL}'
        return ""

    def get_cell_middle(self, n: int, x: int, y: int) -> str:
        """Generate the middle content string representation of a maze cell.

        This method creates the visual middle row of a cell, displaying walls,
        openings, and cell content based on the cell's bit configuration and
        special properties.

        The bit encoding determines wall presence:
            - Bit 0 (leftmost): Left wall (1 = wall, 0 = opening)
            - Bit 2: Right wall (1 = wall, 0 = opening)

        Args:
            n (int): A 4-bit integer encoding the cell's wall configuration.
            x (int): The x-coordinate (column) of the cell.
            y (int): The y-coordinate (row) of the cell.

        Returns:
            str: A colored string representing the middle row of the cell,
                including left wall, content, and right wall.
        """

        WALL: str = f'{self.wall_color["value"]}█{RESET}'
        RIGHT_WALL: str = " "
        LEFT_WALL: str = " "
        CELL_CONTENT: str = "  "

        is_in_path: bool = self.ft_is_in_path(x, y)
        if self.show_path and is_in_path:
            if (x + 1, y) in self.solution_path:
                RIGHT_WALL = f'{self.solution_color["value"]}█{RESET}'
            if (x - 1, y) in self.solution_path:
                LEFT_WALL = f'{self.solution_color["value"]}█{RESET}'
            if (x, y) in self.solution_path[1:-1]:
                CELL_CONTENT = f'{self.solution_color["value"]}██{RESET}'

        if (x == self.ENTRY[0]) and (y == self.ENTRY[1]):
            CELL_CONTENT = f'{COLORS["Red"]["value"]}██{RESET}'
        elif (x == self.EXIT[0]) and (y == self.EXIT[1]):
            CELL_CONTENT = f'{COLORS["Lime"]["value"]}██{RESET}'
        elif self.grid[y][x].fixed:
            CELL_CONTENT = f'{self.pattern_color["value"]}██{RESET}'

        bits: str = self.get_bits(n)
        if (self.grid[y][x].fixed):
            WALL = f'{self.pattern_color["value"]}█{RESET}'
            return f'{WALL}{CELL_CONTENT}{WALL}'
        elif (bits[0] == "1" and bits[2] == "1"):
            return f'{WALL}{CELL_CONTENT}{WALL}'
        elif (bits[0] == "1" and bits[2] == "0"):
            return f'{WALL}{CELL_CONTENT}{RIGHT_WALL}'
        elif (bits[0] == "0" and bits[2] == "1"):
            return f'{LEFT_WALL}{CELL_CONTENT}{WALL}'
        elif (bits[0] == "0" and bits[2] == "0"):
            return f'{LEFT_WALL}{CELL_CONTENT}{RIGHT_WALL}'
        return ""

    def render_maze(self) -> None:
        """Render and display the complete maze to the terminal.

        This method clears the screen and draws the entire maze grid by
        iterating through each cell and printing its top and middle borders.
        Gracefully handles user interruption (Ctrl+C or Ctrl+D).

        Returns:
            None

        Raises:
            SystemExit: On KeyboardInterrupt (Ctrl+C) or EOFError,
            after clearing screen.
        """

        try:
            os.system("clear")
            WALL: str = f'{self.wall_color["value"]}█{RESET}'
            frame: List[str] = []

            for y in range(self.HEIGHT):

                # top
                frame.append(WALL)
                for x in range(self.WIDTH):
                    cell = self.grid[y][x].walls
                    frame.append(self.get_cell_top(cell, x, y))
                frame.append(WALL)
                frame.append("\n")

                # middle
                frame.append(WALL)
                for x in range(self.WIDTH):
                    cell = self.grid[y][x].walls
                    frame.append(self.get_cell_middle(cell, x, y))
                frame.append(WALL)
                frame.append("\n")

            # bottom
            frame.append(WALL)
            for x in range(self.WIDTH):
                frame.append(f'{self.wall_color["value"]}████{RESET}')
            frame.append(WALL)
            frame.append("\n")
            print("".join(frame))

        except (KeyboardInterrupt, EOFError):
            os.system("clear")
            sys.exit(0)

    def dfs_algo(self) -> None:
        """Generate a maze using the Depth-First Search (DFS) algorithm.

        This method creates a maze by performing a depth-first search traversal
        starting from the entry point. It uses a stack-based approach to carve
        passages between cells by removing walls. The algorithm respects fixed
        cells (like the "42" pattern) and avoids carving through them.

        Process:
            1. Start DFS from the entry point
            2. Randomly choose unvisited neighbors and carve passages
            3. Backtrack when no unvisited neighbors remain
            4. Optionally render animation during generation

        Returns:
            None
        """

        try:

            if self.SEED is not None:
                random.seed(self.SEED)

            stack: List[tuple] = []
            current_x, current_y = self.ENTRY
            self.grid[current_y][current_x].visited = True
            stack.append((current_x, current_y))

            while stack:

                current_x, current_y = stack[-1]
                neighbors: List[tuple] = []

                for dx, dy, current_mask, neighbor_mask in self.DIRECTIONS:
                    nx: int = current_x + dx
                    ny: int = current_y + dy
                    if (
                        (0 <= nx < self.WIDTH)
                        and (0 <= ny < self.HEIGHT)
                        and not self.grid[ny][nx].visited
                        and not self.grid[ny][nx].fixed
                    ):
                        neighbors.append(
                            (nx, ny, current_mask, neighbor_mask)
                        )

                if neighbors:
                    nx, ny, current_mask, neighbor_mask = (
                        random.choice(neighbors)
                    )
                    self.grid[current_y][current_x].walls ^= current_mask
                    self.grid[ny][nx].walls ^= neighbor_mask
                    self.grid[ny][nx].visited = True
                    stack.append((nx, ny))

                    if self.render_animation:
                        self.render_maze()
                        time.sleep(self.animation_speed)

                else:
                    stack.pop()

        except (KeyboardInterrupt, EOFError):
            os.system("clear")
            sys.exit(0)

    def prims_algo(self) -> None:
        """Generate a maze using Prim's algorithm.

        This method creates a maze by performing Prim's algorithm, which builds
        the maze by randomly selecting cells from a pool of unvisited neighbors
        adjacent to visited cells. It carves passages by removing walls between
        cells. The algorithm respects fixed cells (like the "42" pattern) and
        avoids carving through them.

        Process:
            1. Mark entry point as visited and add its neighbors to pool
            2. While pool is not empty:
                a. Randomly select a neighbor from the pool
                b. If already visited, skip and continue
                c. Carve passage by removing walls between cells
                d. Mark neighbor as visited
                e. Add neighbor's unvisited neighbors to pool
                f. Optionally render animation

        Returns:
            None
        """

        try:

            if self.SEED is not None:
                random.seed(self.SEED)

            start_x, start_y = self.ENTRY
            self.grid[start_y][start_x].visited = True

            pool: List[tuple] = []

            def add_neighbors_to_pool(x: int, y: int) -> None:
                for dx, dy, current_mask, neighbor_mask in self.DIRECTIONS:
                    nx: int = x + dx
                    ny: int = y + dy
                    if (
                        (0 <= nx < self.WIDTH)
                        and (0 <= ny < self.HEIGHT)
                        and not self.grid[ny][nx].visited
                        and not self.grid[ny][nx].fixed
                    ):
                        pool.append((
                            nx, ny, x, y,
                            current_mask, neighbor_mask
                        ))

            add_neighbors_to_pool(start_x, start_y)

            while pool:

                i: int = random.randrange(len(pool))
                (nx, ny, x, y,
                    current_mask, neighbor_mask) = pool[i]

                pool.pop(i)

                if self.grid[ny][nx].visited:
                    continue

                self.grid[y][x].walls ^= current_mask
                self.grid[ny][nx].walls ^= neighbor_mask
                self.grid[ny][nx].visited = True

                if self.render_animation:
                    self.render_maze()
                    time.sleep(self.animation_speed)

                add_neighbors_to_pool(nx, ny)

        except (KeyboardInterrupt, EOFError):
            os.system("clear")
            sys.exit(0)

    def make_maze_imperfect(self) -> None:
        """This method introduces a small number of extra openings between
        adjacent cells that are not marked `fixed`, creating loops and
        reducing the maze's perfect-tree property.
        It performs the following steps:
        1. Collects candidate neighbor pairs (only right and down directions)
        where both cells are not fixed and the neighbor still has its wall
        in place.
        2. Randomly selects roughly 10% of those candidates (at least one) and
        removes the corresponding walls on both cells, optionally rendering an
        animation after each modification.
        3. Ensures the maze `ENTRY` and `EXIT` cells are open to any adjacent,
        non-fixed cells by removing walls between them and those neighbors,
        again
        optionally rendering after each change.

        Returns:
            None
        """

        directions: List[tuple] = [
            (1, 0, 2, 8),   # Right (East)
            (0, 1, 4, 1)   # Down (South)
        ]
        neighbors: List[tuple] = []

        for y in range(self.HEIGHT):
            for x in range(self.WIDTH):
                if self.grid[y][x].fixed:
                    continue
                for dx, dy, current_mask, neighbor_mask in directions:
                    nx: int = x + dx
                    ny: int = y + dy
                    if (
                        (0 <= nx < self.WIDTH)
                        and (0 <= ny < self.HEIGHT)
                        and not self.grid[ny][nx].fixed
                        and (self.grid[ny][nx].walls & neighbor_mask)
                    ):
                        neighbors.append(
                            (x, y, nx, ny, current_mask, neighbor_mask)
                        )

        random.shuffle(neighbors)
        total = max(1, int(len(neighbors) * 0.1))

        for x, y, nx, ny, current_mask, neighbor_mask in neighbors[:total]:
            self.grid[y][x].walls ^= current_mask
            self.grid[ny][nx].walls ^= neighbor_mask
            if self.render_animation:
                self.render_maze()
                time.sleep(self.animation_speed)

        for current_x, current_y in (self.ENTRY, self.EXIT):
            for dx, dy, current_mask, neighbor_mask in self.DIRECTIONS:
                n_x: int = current_x + dx
                n_y: int = current_y + dy
                if (
                    (0 <= n_x < self.WIDTH)
                    and (0 <= n_y < self.HEIGHT)
                    and not self.grid[n_y][n_x].fixed
                ):
                    if (self.grid[current_y][current_x].walls & current_mask):
                        self.grid[current_y][current_x].walls ^= current_mask
                    if (self.grid[n_y][n_x].walls & neighbor_mask):
                        self.grid[n_y][n_x].walls ^= neighbor_mask
                    if self.render_animation:
                        self.render_maze()
                        time.sleep(self.animation_speed)

    def find_solution(self) -> None:
        """
        Finds the shortest path from the entry to the exit using
        Breadth-First Search (BFS).
        This method traverses the maze grid level by level starting from
        `self.ENTRY`. It evaluates valid adjacent moves by checking the
        current cell's bitwise wall
        mask against directional masks (North, East, South, West).
        The traversal history is recorded in a `came_from` dictionary.

        Once the `self.EXIT` is reached, the method backtracks through
        `came_from` to reconstruct the correct sequence of steps.

        Attributes Modified:
            self.solution_path (List[Tuple[int, int]]): Populated with
            the ordered sequence of (x, y) coordinates representing the
            path from entry to exit.
        """

        directions: List[tuple] = [
            (0, -1, 1),   # Up (North)
            (1,  0, 2),   # Right (East)
            (0,  1, 4),   # Down (South)
            (-1, 0, 8),   # Left (West)
        ]

        came_from: Dict = {self.ENTRY: None}
        queue: deque = deque([self.ENTRY])

        while queue:
            current_x, current_y = queue.popleft()

            if (current_x, current_y) == self.EXIT:
                break

            current_walls: int = self.grid[current_y][current_x].walls

            for dx, dy, wall_mask in directions:
                nx: int = current_x + dx
                ny: int = current_y + dy

                if (
                    (0 <= nx < self.WIDTH)
                    and (0 <= ny < self.HEIGHT)
                    and (current_walls & wall_mask) == 0
                    and (nx, ny) not in came_from
                ):
                    came_from[(nx, ny)] = (current_x, current_y)
                    queue.append((nx, ny))

        self.solution_path = []
        cell: Optional[Tuple[int, int]] = self.EXIT

        while cell is not None:
            self.solution_path.append(cell)
            cell = came_from.get(cell)

        self.solution_path.reverse()

    def generate_output(self) -> None:
        """Generate and write the maze data to an output file.

        This method creates a formatted output containing the maze structure,
        entry/exit points, and the solution path directions.
        The maze is encoded as hexadecimal values representing each cell's
        wall configuration.

        Output format:
            - Lines 1 to HEIGHT: Hexadecimal wall values for each cell
            - Blank line
            - Entry point: x,y coordinates
            - Exit point: x,y coordinates
            - Solution path: Direction characters (N/S/E/W) representing
            movement between consecutive path coordinates

        Direction encoding:
            - 'N': Move North
            - 'S': Move South
            - 'E': Move East
            - 'W': Move West

        Returns:
            None

        Raises:
            SystemExit: If the output file cannot be written due to
            permissions, disk space, or other I/O errors.
        """

        lines: List[str] = []

        for y in range(self.HEIGHT):
            lines.append(
                "".join(f'{self.grid[y][x].walls:X}'
                        f'' for x in range(self.WIDTH))
            )

        lines.append("")
        lines.append(f'{self.ENTRY[0]},{self.ENTRY[1]}')
        lines.append(f'{self.EXIT[0]},{self.EXIT[1]}')

        moves: List[str] = []

        for i in range(1, len(self.solution_path)):
            prev_pos_x, prev_pos_y = self.solution_path[i - 1]
            current_x, current_y = self.solution_path[i]

            if current_y == prev_pos_y + 1:
                moves.append("S")
            elif current_y == prev_pos_y - 1:
                moves.append("N")
            elif current_x == prev_pos_x + 1:
                moves.append("E")
            elif current_x == prev_pos_x - 1:
                moves.append("W")

        lines.append("".join(moves))
        lines.append("")

        try:
            with open(self.OUTPUT_FILE, "w") as output_f:
                output_f.write("\n".join(lines))
        except Exception as e:
            print(f'Output file error: {e}')
            sys.exit(1)
